declare namespace _default {
    const OPACITY: string;
    const VISIBLE: string;
    const EXTENT: string;
    const Z_INDEX: string;
    const MAX_RESOLUTION: string;
    const MIN_RESOLUTION: string;
    const MAX_ZOOM: string;
    const MIN_ZOOM: string;
    const SOURCE: string;
    const MAP: string;
}
export default _default;
//# sourceMappingURL=Property.d.ts.map