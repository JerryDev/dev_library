declare namespace _default {
    const TILELOADSTART: string;
    const TILELOADEND: string;
    const TILELOADERROR: string;
}
export default _default;
export type TileSourceEventTypes = 'tileloadstart' | 'tileloadend' | 'tileloaderror';
//# sourceMappingURL=TileEventType.d.ts.map