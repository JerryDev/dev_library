declare namespace _default {
    const LAYERGROUP: string;
    const SIZE: string;
    const TARGET: string;
    const VIEW: string;
}
export default _default;
//# sourceMappingURL=MapProperty.d.ts.map